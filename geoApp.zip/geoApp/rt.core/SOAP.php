<?php
class _�NtvSOAP{public $EMU='COM',$CLS='XML',$COM,$Name='',$REF='XML',$PRM='',$PRM2='',$PRM3='',$PRM4='',$HS='',$PRT=0;
 
}
?>